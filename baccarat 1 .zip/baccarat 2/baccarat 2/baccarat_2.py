# EP - Design de Software
# Equipe: Rodrigo Lee
# Data: 18/10/2020

import random

x = 100 #carteira
y = 0 #Em quem esta sendo apostado guardado na memoria
z = 0 # valor sendo apostado guardado na mmemoria

#Comeca o jogo
print(">=============================<")
print("O jogador possui", x ,"fichas")
print(">=============================<")


#Pergunta em quem deseja apostar
print("Deseja apostar no Jogador, no Banco ou em Empate? Digite:")
print("j - para apostar no Jogador. b - para apostar no Banco. e - para apostar em Empate.")


#Anuncia em quem deseja apostar
while True:
    y = input(">=============================< ")
    if y == "j":
        print("Você escolheu apostar no Jogador")
        y = "Jogador"
        #Muda nome para Jogador para deixar mais organizado
        break
    elif y == "b":
        print("Você escolheu apostar no Banco")
        y = "Banco"
        #Muda nome para Banco para deixar mais organizado
        break
    elif y == "e":
        print("Você escolheu apostar em Empate")
        y = "Empate"
        #Muda nome para Empate para deixar mais organizado
        break
    else:
        print("A opção", y ,"não é válida, insira novamente")

print(">=============================<")

#Pergunta quanto deseja apostar
#Anuncia quanto foi apostado
while True:
    z = int(input("Qual valor você deseja apostar? "))
    if z <= x:
        print("Você apostou", z, "fichas em", y)
        x = x - z
        print("Você agora possui", x, "fichas")
        break
    else:
        print("Você não possui", z, "fichas")


#CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS// LISTA DE CARTAS E EMBARALHAMENTO DELAS
#CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS// LISTA DE CARTAS E EMBARALHAMENTO DELAS
#CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS CARTAS// LISTA DE CARTAS E EMBARALHAMENTO DELAS
print(">=============================<")
input('Escreva "sortear" para sortear as cartas: ')

naipes = ['corações', 'espadas', 'clubes', 'diamantes']
valorcs = ['K', 'A', '2' ,'3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']
cartas = []

# tiro as cartas antes de "desvendar" elas para os jogadores
for naipe in naipes:
    for valorc in valorcs:
        cartas.append((valorc, naipe))
random.shuffle(cartas)

#CARTAS JOGADOR// AJUSTAMENTO DOS VALORES DAS CARTAS JOGADOR //CARTAS JOGADOR//CARTAS JOGADOR// AJUSTAMENTO DOS VALORES DAS CARTAS JOGADOR
#CARTAS JOGADOR// AJUSTAMENTO DOS VALORES DAS CARTAS JOGADOR //CARTAS JOGADOR//CARTAS JOGADOR// AJUSTAMENTO DOS VALORES DAS CARTAS JOGADOR
#CARTAS JOGADOR// AJUSTAMENTO DOS VALORES DAS CARTAS JOGADOR //CARTAS JOGADOR//CARTAS JOGADOR// AJUSTAMENTO DOS VALORES DAS CARTAS JOGADOR

carta1jogador = cartas[0] #carta1jogador = valorc1 + naipe1
carta2jogador = cartas[1] #carta2jogador = valorc2 + naipe2
carta3jogador = cartas[2] #APENAS É ATIVADO SE O VALOR DA CARTA FOR MENOR DO QUE CINCO
print("As cartas do JOGADOR são", cartas[0], cartas[1])

#CARTA 1 ARRUMA VALOR PARA A SOMA 
if carta1jogador[0] == 'A':
    adc_jogador1 = 1
elif carta1jogador[0] == 'J':
    adc_jogador1 = 0
elif carta1jogador[0] == 'Q':
    adc_jogador1 = 0
elif carta1jogador[0] == 'K':
    adc_jogador1 = 0
elif carta1jogador[0] == "10":
    adc_jogador1 = 0
else:
    adc_jogador1 = int(carta1jogador[0]) 

#CARTA 2 ARRUMA VALOR PARA A SOMA 
if carta2jogador[0] == 'A':
    adc_jogador2 = 1
elif carta2jogador[0] == 'J':
    adc_jogador2 = 0
elif carta2jogador[0] == 'Q':
    adc_jogador2 = 0
elif carta2jogador[0] == 'K':
    adc_jogador2 = 0
elif carta2jogador[0] == "10":
    adc_jogador2 = 0
else:
    adc_jogador2 = int(carta2jogador[0]) 

#CARTA 3 ARRUMA VALOR PARA A SOMA
if carta3jogador[0] == 'A':
    adc_jogador3 = 1
elif carta3jogador[0] == 'J':
    adc_jogador3 = 0
elif carta3jogador[0] == 'Q':
    adc_jogador3 = 0
elif carta3jogador[0] == 'K':
    adc_jogador3 = 0
elif carta3jogador[0] == "10":
    adc_jogador3 = 0
else:
    adc_jogador3 = int(carta3jogador[0]) 

#Adiciona valor das duas cartas
adc_jog_tot = int(adc_jogador1) + int(adc_jogador2)

if int(adc_jog_tot) < 6:
    print("A soma das cartas do JOGADOR foram menor do que 6, as novas cartas do JOGADOR são: ", cartas[0], cartas[1], cartas[2])
    adc_jog_tot = adc_jogador1 + adc_jogador2 + adc_jogador3

    if int(adc_jog_tot) > 10:
        adc_jog_tot_ultim = str(adc_jog_tot) #pega ultimo algarismo
        adc_jog_tot = adc_jog_tot_ultim[1]
elif int(adc_jog_tot) > 10:    
        adc_jog_tot_ultim = str(adc_jog_tot) #pega ultimo algarismo
        adc_jog_tot = adc_jog_tot_ultim[1]


#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO// AJUSTAMENTO DOS VALORES DAS CARTAS BANCO
#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO// AJUSTAMENTO DOS VALORES DAS CARTAS BANCO
#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO// AJUSTAMENTO DOS VALORES DAS CARTAS BANCO
#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO//#CARTAS BANCO// AJUSTAMENTO DOS VALORES DAS CARTAS BANCO
carta1banco = cartas[3] #carta1banco = valorc3 + naipe3
carta2banco = cartas[4] #carta2banco = valorc4 + naipe4
carta3banco = cartas[5] #APENAS É ATIVADO SE O VALOR DA CARTA FOR MENOR DO QUE CINCO
print("As cartas do BANCO são", cartas[3], cartas[4])

#CARTA 1 ARRUMA VALOR PARA A SOMA 
if carta1banco[0] == 'A':
    adc_banco1 = 1
elif carta1banco[0] == 'J':
    adc_banco1 = 0
elif carta1banco[0] == 'Q':
    adc_banco1 = 0
elif carta1banco[0] == 'K':
    adc_banco1 = 0
elif carta1banco[0] == "10":
    adc_banco1 = 0
else:
    adc_banco1 = int(carta1banco[0]) 

#CARTA 2 ARRUMA VALOR PARA A SOMA 
if carta2banco[0] == 'A':
    adc_banco2 = 1
elif carta2banco[0] == 'J':
    adc_banco2 = 0
elif carta2banco[0] == 'Q':
    adc_banco2 = 0
elif carta2banco[0] == 'K':
    adc_banco2 = 0
elif carta2banco[0] == "10":
    adc_banco2 = 0
else:
    adc_banco2 = int(carta2banco[0]) 


#CARTA 3 ARRUMA VALOR PARA A SOMA
if carta3banco[0] == 'A':
    adc_banco3 = 1
elif carta3banco[0] == 'J':
    adc_banco3 = 0
elif carta3banco[0] == 'Q':
    adc_banco3 = 0
elif carta3banco[0] == 'K':
    adc_banco3 = 0
elif carta3banco[0] == "10":
    adc_banco3 = 0
else:
    adc_banco3 = int(carta3banco[0]) 

#Adiciona valor das duas cartas
adc_banco_tot = adc_banco1 + adc_banco2

if int(adc_banco_tot) < 6:
    print("A soma das cartas do BANCO foram menor do que 6, as novas cartas do BANCO são: ", cartas[0], cartas[1], cartas[2])
    adc_banco_tot = adc_banco1 + adc_banco2 + adc_banco3

    if adc_banco_tot > 10:
        adc_banco_tot_ultim = str(adc_banco_tot) #pega ultimo algarismo
        adc_banco_tot = adc_banco_tot_ultim[1]
elif int(adc_banco_tot) > 10:
        adc_banco_tot_ultim = str(adc_banco_tot) #pega ultimo algarismo
        adc_banco_tot = adc_banco_tot_ultim[1]

#AQUI SE ENCERRA O AJUSTAMENTO DO VALOR DAS CARTAS E "OUTPUT" DAS CARTAS//AQUI SE ENCERRA O AJUSTAMENTO DO VALOR DAS CARTAS E "OUTPUT" DAS CARTAS//
#AQUI SE ENCERRA O AJUSTAMENTO DO VALOR DAS CARTAS E "OUTPUT" DAS CARTAS//AQUI SE ENCERRA O AJUSTAMENTO DO VALOR DAS CARTAS E "OUTPUT" DAS CARTAS//
#AQUI SE ENCERRA O AJUSTAMENTO DO VALOR DAS CARTAS E "OUTPUT" DAS CARTAS//AQUI SE ENCERRA O AJUSTAMENTO DO VALOR DAS CARTAS E "OUTPUT" DAS CARTAS//
#AQUI SE ENCERRA O AJUSTAMENTO DO VALOR DAS CARTAS E "OUTPUT" DAS CARTAS//AQUI SE ENCERRA O AJUSTAMENTO DO VALOR DAS CARTAS E "OUTPUT" DAS CARTAS//

print(">=============================<")



#AQUI Y SE REFERE EM QUEM O USUARIO APOSTOU
#COMPARA VALORES FINAIS DAS CARTAS
#DECIDE VENCEDOR E DA RESPOSTAS AVISANDO A RAZAO PORQUE VOCE PERDEU

#USUARIO APOSTA NO JOGADOR
if y == "Jogador":
    if adc_jog_tot > adc_banco_tot: #Jogador vence, e usuario apostou no jogador
        print("O Jogador venceu! Você recebeu:", z ,"fichas")
        x = x + (z*2)
        print(">=============================<")
        print("Agora, você possui", x, "fichas")
    elif adc_jog_tot < adc_banco_tot:
        print("O Banco venceu! Você perdeu:", z ,"fichas")
        print(">=============================<")
        print("Agora, você possui", x, "fichas")
    elif adc_jog_tot == adc_banco_tot:
        print("O jogo empatou! Você perdeu:", z ,"fichas")
        print(">=============================<")
        print("Agora, você possui", x, "fichas")
#USUARIO APOSTA NO BANCO
elif y == "Banco":
    if adc_jog_tot > adc_banco_tot:
        print("O Jogador venceu! Você perdeu:", z ,"fichas")
        print(">=============================<")
        print("Agora, você possui", x, "fichas")
    elif adc_jog_tot < adc_banco_tot:
        x = x + z #adiciona valor apostado
        z = z * 0.95 #MULTIPLICA 95 PORCENTAGEM PARA PODER FALAR VALOR RECEBIDO, DEPOIS DE FALAR ADICIONA NA CARTEIRA
        print("O Banco venceu! Você recebeu:", z ,"fichas")
        x = x + z #da o valor a mais, descontando o apostado que ja foi dado, para a carteira
        print(">=============================<")
        print("Agora, você possui", x, "fichas")
    elif adc_jog_tot == adc_banco_tot:
        print("O jogo empatou! Você perdeu:", z ,"fichas")
        print(">=============================<")
        print("Agora, você possui", x, "fichas")
#USUARIO APOSTA EM EMPATE
elif y == "Empate":
    if adc_jog_tot > adc_banco_tot:
        print("O Jogador empatou! Você perdeu:", z ,"fichas")   
        print(">=============================<")
        print("Agora, você possui", x, "fichas")
    elif adc_jog_tot < adc_banco_tot:
        print("O jogo empatou! Você perdeu:", z ,"fichas")
        print(">=============================<")
        print("Agora, você possui", x, "fichas")
    elif adc_jog_tot == adc_banco_tot:
        x = x + z #devolve valor apostado
        z = z*8 
        print("O jogo empatou! Você recebeu:", z ,"fichas")
        x = x + z #da o valor a mais, descontando o apostado que ja foi dado, para a carteira
        print(">=============================<")
        print("Agora, você possui", x, "fichas")

print(">=============================<")
input('Aperte ENTER para sair')
